<?php
$WP_PATH = implode("/", (explode("/", $_SERVER["PHP_SELF"], -6)));
require_once($_SERVER['DOCUMENT_ROOT'].$WP_PATH.'/wp/wp-load.php');

global $wpdb, $current_user, $wpscfunction;

include_once( WPPATT_ABSPATH . 'includes/class-wppatt-custom-function.php' );
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">

    <title>index</title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width; initial-scale=1.0" />
    <link rel="stylesheet" type="text/css" href="./css/fonts.css" />
    <link rel="stylesheet" type="text/css" href="./css/styles.css" />
    <link rel="stylesheet" type="text/css" href="./styles.css" />
    <link rel="stylesheet" type="text/css" href="./css/prism.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>

<body>
    <header>
        <div class="headline">
            <h1>PATT</h1>
            <h2>Location Assignment Application</h2>
        </div>
    </header>
    <section id="container" class="container">
        <div class="controls">
            <p>
                <strong>Scan a location barcode along with either a series of boxes or pallets.</strong><br /> Only one location barcode can be scanned for each submission.
            </p>
            <button type="button" class="icon-barcode button scan">Start Scanning</button>
            
            
            <div class="readers">

                <input type="hidden" value="code_128_reader" />
                <input type="text" id="location" value="" style="display:none;" />
                <input type="text" id="box_pallet_array" value="" style="display:none;" />
                
                <!--<label>
                    <span>EAN-13</span>
                    <input type="checkbox" checked name="ean_reader" />
                </label>
                <label>
                    <span>EAN-8</span>
                    <input type="checkbox" name="ean_8_reader" />
                </label>
                <label>
                    <span>UPC-E</span>
                    <input type="checkbox" name="upc_e_reader" />
                </label>
                <label>
                    <span>Code 39</span>
                    <input type="checkbox" checked name="code_39_reader" />
                </label>
                <label>
                    <span>Codabar</span>
                    <input type="checkbox" name="codabar_reader" />
                </label>
                <label>
                    <span>Code 128</span>
                    <input type="checkbox" checked name="code_128_reader" />
                </label>
                <label>
                    <span>Interleaved 2 of 5</span>
                    <input type="checkbox" name="i2of5_reader" />
                </label>-->
            </div>
            <span id="box_pallet_count"></span>
        </div>
        <div class="overlay overlay--inline">
            <div class="overlay__content">
                <div class="overlay__close">X</div>
            </div>
        </div>
    </section>
    <ul class="results">
    <li>
    <button type="button" id="refresh" onClick="window.location.reload();" class="icon-refresh button refresh">Reset</button>
    </li>
    </ul>
<script>
function wppatt_barcode_assignment_update(){		
		   $.post(
   '<?php echo WPPATT_PLUGIN_URL; ?>includes/admin/pages/scripts/update_barcode_assignment.php',{
postvarslocation: $("#location").val(),
postvarsboxpallet: $("#box_pallet_array").val()
}, 
   function (response) {
      if(!alert(response)){window.location.reload();}
   });
}
</script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/quagga/1.0.0-beta.2/quagga.js"></script>
    <script src="index.js" type="text/javascript"></script>
    <script src="./vendor/prism.js"></script>
</body>

</html>
